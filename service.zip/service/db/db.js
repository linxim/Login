module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: 'root',
        port: '3306',
        database: 'login'
    }
}
